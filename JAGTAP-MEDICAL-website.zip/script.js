const $ = (s) => document.querySelector(s);
const chatbox = $('#chatbox');
const toggle = $('#chatToggle');
if (toggle) toggle.addEventListener('click', () => chatbox.classList.toggle('open'));
$('#closeChat')?.addEventListener('click', () => chatbox.classList.remove('open'));
const answers = {"store hours":"We are open Monday–Saturday, 8:00 AM–9:30 PM, and Sunday, 9:00 AM–2:00 PM.","vet medicines":"Yes—our veterinary section includes medicines, supplements and care essentials for companion and farm animals.","upload prescription":"Use the Upload Prescription area on this page. Our pharmacist will review it and contact you to confirm."};
function addMessage(text, type='bot'){const el=document.createElement('div');el.className=`message ${type}`;el.textContent=text;$('#messages').insertBefore(el,$('.suggestions'));}
document.querySelectorAll('.suggestions button').forEach(b=>b.addEventListener('click',()=>{const q=b.textContent.toLowerCase();addMessage(b.textContent,'user');setTimeout(()=>addMessage(answers[q]||"Our care team can help with that. Please call or WhatsApp +91 98765 43210."),250)}));
$('#chatForm')?.addEventListener('submit',e=>{e.preventDefault();const input=$('#chatInput');const q=input.value.trim();if(!q)return;addMessage(q,'user');input.value='';setTimeout(()=>addMessage('Thanks for asking. For personalised medicine advice, please speak with our pharmacist or book a doctor consultation.'),350)});
$('#uploadBtn')?.addEventListener('click',()=>$('#fileInput').click());
$('#fileInput')?.addEventListener('change',e=>{if(e.target.files[0]){$('#uploadBtn').querySelector('b').textContent=`${e.target.files[0].name} selected`;$('#uploadBtn').querySelector('small').textContent='Ready for pharmacist review';}});
$('#bookBtn')?.addEventListener('click',()=>{const b=$('#bookBtn');b.textContent='Request received — we will call you';b.disabled=true;b.style.opacity='.75';});
const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')}),{threshold:.12});document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));
